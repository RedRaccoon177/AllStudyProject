﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14_Project_Assignment
{
    internal class Car
    {
        public string[] _carName;
        int _carNum;

        public int CarHp
        {
            get; set;
        }
    }
}
