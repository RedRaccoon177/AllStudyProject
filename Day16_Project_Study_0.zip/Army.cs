﻿using System;


namespace Day16_Project_Study_0
{
    partial class Army
    {
        public void PrintAllShip()
        {
        }

    }
}
