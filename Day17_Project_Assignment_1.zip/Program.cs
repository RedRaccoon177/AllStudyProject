﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day17_Project_Assignment_1
{
    enum MobTybe
    {
        Normal, Fire, Water, Grass, electric
    }

    //심화 과제1
    abstract class Monster
    {
        protected int _level;
        protected MobTybe _type;
        protected string _name;
        abstract public void BaseAttack();

        protected Monster(int level, int tybe, string name)
        {
            _level = level;
            _type = (MobTybe)tybe;
            _name = name;
        }
    }

    class Pikachu : Monster
    {
        public override void BaseAttack()
        {
            Console.WriteLine("전광석화");
        }

        public Pikachu() : base(1,4,"전기공학쥐")
        {
        }
    }

    class Squirtle: Monster
    {
        public override void BaseAttack()
        {
            Console.WriteLine("물총발사");
        }
        public Squirtle() : base(1, 2, "꼬부기?")
        {
        }

    }

    class Bulbasaur: Monster
    {
        public override void BaseAttack()
        {
            Console.WriteLine("덩굴채찍");
        }
        public Bulbasaur() : base(1, 3, "딤섬같은놈")
        {
        }
    }

    class Charmander: Monster
    {
        public override void BaseAttack()
        {
            Console.WriteLine("화염방사");
        }
        public Charmander() : base(1, 1, "용가리")
        {
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
