﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day10_Project_Study
{
    internal class Program
    {
        #region 어제 수업 구조체(struct)
        //Struct 구조체
        //public struct Point
        //{
        //    public int x, y;
        //}

        //static void Main(string[] args)
        //{
        //    Point myPoint = new Point();    //C#에서 구조체는 값타임
        //    int num = new int();
        //    myPoint.x = 10;
        //    myPoint.y = 11;
        //}
        #endregion

        #region 1. 어제수업 열거형(enum)
        //enum Places     //열거형 설계도
        //{
        //    start, huntingPlace, village = 5, market, end
        //}
        #endregion

        #region 1. 어제수업 열거형(enum)
        //static void Main(string[] args)
        //{
        //    Places places;  //우리가 만든 자료형으로 변수 만듦
        //    places = Places.huntingPlace;

        //    for (int i = (int)Places.start; i < (int)Places.end; i++)
        //    {
        //        Console.WriteLine((Places)i);       // (이넘)i는 전환 가능
        //        // Enum IsDefined();                   
        //    }
        //}
        #endregion
    }
}
