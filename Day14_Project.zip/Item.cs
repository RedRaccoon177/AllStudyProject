﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14_Project_Study
{
    internal class Item
    {
        public string itemName;
        public string itemType;
        public int price;
    }
}
