﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day18_Project_Assignment_0
{
    //플레이어어와 상호작용 할 특정 NPC들이 사용할 인터페이스
    interface IInteractable
    {
        void Interact();
    }

    //NPC 뼈대 추상 클래스
    abstract class AllNPC
    {
        public float _X;
        public string _name;
    }

    //강화 NPC
    class StrengthenNPC : AllNPC, IInteractable
    {
        public void Interact()
        {
            Console.WriteLine("강화를 수행합니다. 깡! 깡!");
        }
    }

    //창고 NPC
    class WarehouseNPC : AllNPC, IInteractable
    {
        public void Interact()
        {
            Console.WriteLine("창고를 수행합니다. 철컥~?");
        }
    }

    //잡 NPC
    class JobNPC : AllNPC
    {

    }

    class Player
    {
        float _X;
        public void InteractWithNPC(IInteractable npc)
        {
            npc.Interact();
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Player player = new Player();
            IInteractable[] allNPC = new IInteractable[2];
            allNPC[0] = new StrengthenNPC();
            allNPC[1] = new WarehouseNPC();

            player.InteractWithNPC(allNPC[0]);
            player.InteractWithNPC(allNPC[1]);


            //그냥 잡npc는 IInteractable이 아니여서 상호작용이 안된다.
        }
    }
}
