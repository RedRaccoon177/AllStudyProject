﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day18_Project_Assignment_0
{
    interface Iwhat
    {

    }
    internal class Program
    {
        static void Main(string[] args)
        {



        }
    }
}
